Compile stage2_report.tex twice with XeLaTeX.
Keep the figures/ directory beside the TeX file.
SQL highlighting uses listings and does not require shell-escape.
The font setup falls back from Windows fonts to CMU fonts.
